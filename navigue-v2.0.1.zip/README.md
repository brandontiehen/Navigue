/**
	* "Navigue" - Version 2.0
	* Developed/Revamped by Brandon Tiehen
	* Copyright 2024 (c) All Rights Reserved.
	* https://brandontiehen.github.io
	* Insert: <body onLoad="landingPage()">
	* Default Classes/IDs: #navigation, a.nav-a, (edit as necessary)
	* Default sections: #landing #about, #portfolio, #contact, (edit as necessary)
	* HTML & CSS Template (Useful, but optional) at bottom of this file. Not included in minified file.
*/